import os
import json
import shutil
import zipfile
from pathlib import Path

import duckdb
from flask import Flask, jsonify, request

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
ARCHIVE = ROOT / 'New folder.zip'

if ARCHIVE.exists() and not any(DATA.glob('*_cleaned.csv')):
    with zipfile.ZipFile(ARCHIVE) as archive:
        for entry in archive.infolist():
            if not entry.is_dir() and entry.filename.lower().endswith('.csv'):
                destination = DATA / Path(entry.filename).name
                with archive.open(entry) as source, destination.open('wb') as target:
                    shutil.copyfileobj(source, target)

DB = duckdb.connect(str(ROOT / 'healthcare.duckdb'))
TABLES = {}
for path in sorted(DATA.glob('*_cleaned.csv')):
    name = path.stem.removesuffix('_cleaned')
    identifier = name.replace('"', '""')
    csv_path = str(path.resolve()).replace('\\', '/').replace("'", "''")
    DB.execute(f'''CREATE OR REPLACE VIEW "{identifier}" AS
        SELECT * FROM read_csv_auto('{csv_path}', sample_size=20000, all_varchar=false)''')
    TABLES[name] = str(path)

app = Flask(__name__)


def records(query, params=None, limit=1000):
    df = DB.execute(query, params or []).fetchdf().head(limit)
    return json.loads(df.to_json(orient='records', date_format='iso'))


def filters():
    args = []
    conditions = ['1=1']
    for key, expression in (
        ('start', 'TRY_CAST(e.START AS DATE) >= ?'),
        ('end', 'TRY_CAST(e.START AS DATE) <= ?'),
        ('class', 'e.ENCOUNTERCLASS = ?'),
        ('gender', 'p.GENDER = ?'),
    ):
        value = request.args.get(key)
        if value and value != 'All':
            conditions.append(expression)
            args.append(value)
    return ' AND '.join(conditions), args


def quoted_table(table):
    return '"' + table.replace('"', '""') + '"'


@app.get('/api/health')
def health():
    return jsonify({'status': 'ok', 'tables': list(TABLES)})


@app.get('/api/options')
def options():
    classes = [r[0] for r in DB.execute('''SELECT DISTINCT ENCOUNTERCLASS FROM encounters
        WHERE ENCOUNTERCLASS IS NOT NULL ORDER BY 1''').fetchall()]
    genders = [r[0] for r in DB.execute('''SELECT DISTINCT GENDER FROM patients
        WHERE GENDER IS NOT NULL ORDER BY 1''').fetchall()]
    dates = DB.execute('''SELECT CAST(MIN(TRY_CAST(START AS DATE)) AS VARCHAR),
        CAST(MAX(TRY_CAST(START AS DATE)) AS VARCHAR) FROM encounters''').fetchone()
    return jsonify({'classes': classes, 'genders': genders, 'dates': dates})


@app.get('/api/overview')
def overview():
    where, args = filters()
    base = f'FROM encounters e JOIN patients p ON e.PATIENT = p.Id WHERE {where}'
    kpis = DB.execute(f'''SELECT COUNT(*), COUNT(DISTINCT e.PATIENT),
        COUNT(DISTINCT e.ORGANIZATION),
        SUM(TRY_CAST(e.TOTAL_CLAIM_COST AS DOUBLE)),
        SUM(TRY_CAST(e.PAYER_COVERAGE AS DOUBLE)),
        AVG(TRY_CAST(e.TOTAL_CLAIM_COST AS DOUBLE)) {base}''', args).fetchone()
    trend = records(f'''SELECT strftime(TRY_CAST(e.START AS DATE), '%Y-%m') AS month,
        COUNT(*) AS encounters,
        ROUND(SUM(TRY_CAST(e.TOTAL_CLAIM_COST AS DOUBLE)), 2) AS claims
        {base} GROUP BY 1 ORDER BY 1''', args, 10000)
    classes = records(f'''SELECT e.ENCOUNTERCLASS AS category, COUNT(*) AS value
        {base} GROUP BY 1 ORDER BY 2 DESC''', args)
    top_conditions = records(f'''SELECT c.DESCRIPTION AS category, COUNT(*) AS value
        FROM conditions c WHERE c.PATIENT IN
        (SELECT DISTINCT e.PATIENT {base})
        GROUP BY 1 ORDER BY 2 DESC LIMIT 15''', args)
    return jsonify({'kpis': dict(zip(
        ['encounters', 'patients', 'organizations', 'claims', 'coverage', 'avg_claim'], kpis)),
        'trend': trend, 'classes': classes, 'top_conditions': top_conditions})


@app.get('/api/explore')
def explore():
    table = request.args.get('table', 'encounters')
    if table not in TABLES:
        return jsonify({'error': 'Invalid table'}), 400
    try:
        size = min(max(int(request.args.get('limit', '100')), 1), 2000)
        offset = max(int(request.args.get('offset', '0')), 0)
    except (TypeError, ValueError):
        return jsonify({'error': 'limit and offset must be integers'}), 400
    identifier = quoted_table(table)
    # DESCRIBE returns column name at index 0 and data type at index 1.
    columns = [row[0] for row in DB.execute(f'DESCRIBE {identifier}').fetchall()]
    total = DB.execute(f'SELECT COUNT(*) FROM {identifier}').fetchone()[0]
    rows = records(f'SELECT * FROM {identifier} LIMIT ? OFFSET ?', [size, offset], size)
    return jsonify({'columns': columns, 'total': total, 'rows': rows})


@app.get('/api/quality')
def quality():
    stats = []
    for name in TABLES:
        identifier = quoted_table(name)
        count = DB.execute(f'SELECT COUNT(*) FROM {identifier}').fetchone()[0]
        column_count = len(DB.execute(f'DESCRIBE {identifier}').fetchall())
        stats.append({'table': name, 'rows': count, 'columns': column_count})
    return jsonify({'tables': stats})


@app.get('/api/finance')
def finance():
    where, args = filters()
    base = f'FROM encounters e JOIN patients p ON e.PATIENT = p.Id WHERE {where}'
    payer_base = (f'FROM encounters e JOIN patients p ON e.PATIENT = p.Id '
                  f'LEFT JOIN payers py ON e.PAYER = py.Id WHERE {where}')
    payers = records(f'''SELECT COALESCE(py.NAME, 'Unknown') AS payer,
        COUNT(*) AS encounters,
        ROUND(SUM(TRY_CAST(e.TOTAL_CLAIM_COST AS DOUBLE)), 2) AS claims,
        ROUND(SUM(TRY_CAST(e.PAYER_COVERAGE AS DOUBLE)), 2) AS coverage
        {payer_base} GROUP BY 1 ORDER BY claims DESC LIMIT 20''', args)
    monthly = records(f'''SELECT strftime(TRY_CAST(e.START AS DATE), '%Y-%m') AS month,
        ROUND(SUM(TRY_CAST(e.TOTAL_CLAIM_COST AS DOUBLE)), 2) AS claims,
        ROUND(SUM(TRY_CAST(e.PAYER_COVERAGE AS DOUBLE)), 2) AS coverage
        {base} GROUP BY 1 ORDER BY 1''', args, 10000)
    return jsonify({'payers': payers, 'monthly': monthly})


@app.get('/api/cohorts')
def cohorts():
    where, args = filters()
    base = f'FROM encounters e JOIN patients p ON e.PATIENT = p.Id WHERE {where}'
    gender = records(f'''SELECT COALESCE(p.GENDER, 'Unknown') AS group_name,
        COUNT(DISTINCT p.Id) AS patients, COUNT(*) AS encounters,
        ROUND(AVG(TRY_CAST(e.TOTAL_CLAIM_COST AS DOUBLE)), 2) AS avg_claim
        {base} GROUP BY 1''', args)
    age = records(f'''SELECT CASE
        WHEN TRY_CAST(p.BIRTHDATE AS DATE) IS NULL OR TRY_CAST(e.START AS DATE) IS NULL
            THEN 'Unknown'
        WHEN date_diff('year', TRY_CAST(p.BIRTHDATE AS DATE), TRY_CAST(e.START AS DATE)) < 18 THEN 'Under 18'
        WHEN date_diff('year', TRY_CAST(p.BIRTHDATE AS DATE), TRY_CAST(e.START AS DATE)) < 40 THEN '18-39'
        WHEN date_diff('year', TRY_CAST(p.BIRTHDATE AS DATE), TRY_CAST(e.START AS DATE)) < 65 THEN '40-64'
        ELSE '65+' END AS group_name, COUNT(*) AS encounters
        {base} GROUP BY 1 ORDER BY 1''', args)
    return jsonify({'gender': gender, 'age': age})



@app.get('/api/hospital-performance')
def hospital_performance():
    """Encounter-derived hospital operations; never infer missing operational KPIs."""
    where, args = filters()
    base = f'FROM encounters e JOIN patients p ON e.PATIENT = p.Id WHERE {where}'
    inpatient = "LOWER(COALESCE(e.ENCOUNTERCLASS, '')) = 'inpatient'"
    outpatient = "LOWER(COALESCE(e.ENCOUNTERCLASS, '')) IN ('ambulatory', 'outpatient', 'wellness')"
    daily = records(f"""SELECT CAST(TRY_CAST(e.START AS DATE) AS VARCHAR) AS day,
        COUNT(*) AS admissions {base} AND {inpatient}
        AND TRY_CAST(e.START AS DATE) IS NOT NULL
        GROUP BY 1 ORDER BY 1""", args, 100000)
    stay = records(f"""SELECT strftime(TRY_CAST(e.START AS DATE), '%Y-%m') AS month,
        ROUND(AVG(date_diff('minute', TRY_CAST(e.START AS TIMESTAMP),
            TRY_CAST(e.STOP AS TIMESTAMP)) / 1440.0), 2) AS days
        {base} AND {inpatient}
        AND TRY_CAST(e.START AS TIMESTAMP) IS NOT NULL
        AND TRY_CAST(e.STOP AS TIMESTAMP) IS NOT NULL
        AND TRY_CAST(e.STOP AS TIMESTAMP) >= TRY_CAST(e.START AS TIMESTAMP)
        GROUP BY 1 ORDER BY 1""", args, 10000)
    visits = records(f"""SELECT strftime(TRY_CAST(e.START AS DATE), '%Y-%m') AS month,
        CASE WHEN {inpatient} THEN 'IPD'
             WHEN {outpatient} THEN 'OPD'
             ELSE 'Other encounter classes' END AS visit_type,
        COUNT(*) AS visits {base}
        AND TRY_CAST(e.START AS DATE) IS NOT NULL
        GROUP BY 1, 2 ORDER BY 1, 2""", args, 30000)
    organizations = records(f"""SELECT COALESCE(o.NAME, 'Unknown organization') AS organization,
        ROUND(SUM(TRY_CAST(e.TOTAL_CLAIM_COST AS DOUBLE)), 2) AS claim_amount
        FROM encounters e JOIN patients p ON e.PATIENT = p.Id
        LEFT JOIN organizations o ON e.ORGANIZATION = o.Id
        WHERE {where} GROUP BY 1 ORDER BY claim_amount DESC NULLS LAST LIMIT 12""", args, 20)
    summary = DB.execute(f"""SELECT
        COUNT(*) FILTER (WHERE {inpatient}),
        ROUND(AVG(CASE WHEN {inpatient}
            AND TRY_CAST(e.STOP AS TIMESTAMP) >= TRY_CAST(e.START AS TIMESTAMP)
            THEN date_diff('minute', TRY_CAST(e.START AS TIMESTAMP),
                TRY_CAST(e.STOP AS TIMESTAMP)) / 1440.0 END), 2),
        COUNT(*) FILTER (WHERE {outpatient}),
        COUNT(*) FILTER (WHERE {inpatient}),
        ROUND(SUM(TRY_CAST(e.TOTAL_CLAIM_COST AS DOUBLE)), 2),
        ROUND(SUM(TRY_CAST(e.PAYER_COVERAGE AS DOUBLE)), 2)
        {base}""", args).fetchone()
    return jsonify({
        'summary': dict(zip(['inpatient_encounters', 'avg_inpatient_stay_days',
                             'opd_visits', 'ipd_visits', 'total_claim_amount',
                             'payer_coverage_amount'], summary)),
        'daily_admissions': daily,
        'length_of_stay': stay,
        'opd_ipd': visits,
        'organizations': organizations,
        'availability': {
            'daily_admissions': 'Inpatient encounter starts; not verified physical admissions.',
            'length_of_stay': 'Duration between inpatient encounter START and STOP; not validated discharge LOS.',
            'opd_ipd': 'OPD maps ambulatory/outpatient/wellness; IPD maps inpatient; other classes excluded from ratio.',
            'revenue': 'Claim amounts grouped by organization, not recognized revenue by department.',
            'bed_occupancy': 'Unavailable: no staffed-bed capacity or occupied-bed census.',
            'emergency_response': 'Unavailable: no emergency arrival and first-response timestamps.',
            'lab_turnaround': 'Unavailable: no lab order and result timestamps.',
            'claim_approval': 'Unavailable: payer coverage amount does not establish approval status.'
        }
    })

if __name__ == '__main__':
    print('AETHER backend started; tables:', ', '.join(TABLES) or '(none)')
    app.run(host='127.0.0.1', port=int(os.getenv('PORT', '5000')), debug=False)
