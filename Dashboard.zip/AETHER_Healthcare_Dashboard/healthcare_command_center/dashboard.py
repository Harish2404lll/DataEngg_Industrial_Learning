import os
from datetime import date

import pandas as pd
import plotly.express as px
import requests
import streamlit as st

st.set_page_config(page_title="AETHER | Healthcare Intelligence", page_icon="🩺", layout="wide", initial_sidebar_state="expanded")
st.markdown("""<style>.stApp{background:#0a1020;color:#e9efff}[data-testid="stSidebar"]{background:#101b31}div[data-testid="stMetric"]{background:#14223a;padding:18px;border:1px solid #273d5a;border-radius:14px}h1,h2,h3{color:#e7f1ff}.stButton>button{border-radius:10px}</style>""", unsafe_allow_html=True)
API = os.getenv("API_URL", "http://127.0.0.1:5000").rstrip("/")

@st.cache_data(ttl=120, show_spinner=False)
def get(endpoint, params=()):
    response = requests.get(f"{API}/api/{endpoint}", params=dict(params), timeout=120)
    response.raise_for_status()
    payload = response.json()
    if not isinstance(payload, dict):
        raise ValueError(f"/api/{endpoint} returned {type(payload).__name__}, expected JSON object. Check Flask endpoint return value.")
    return payload

def fetch(endpoint, params=()):
    try:
        return get(endpoint, params)
    except (requests.RequestException, ValueError) as exc:
        st.error(f"Unable to load /api/{endpoint}: {exc}")
        st.info("Start the Flask backend with `python backend.py` and check http://127.0.0.1:5000/api/health")
        st.stop()

def frame(rows, columns=None):
    # Construct from JSON records first; never assign untrusted API labels by position.
    df = pd.DataFrame(rows or [])
    if df.empty and columns:
        df = pd.DataFrame(columns=list(dict.fromkeys(columns)))
    df.columns = [str(c) for c in df.columns]
    if not df.columns.is_unique:
        counts = {}
        renamed = []
        for col in df.columns:
            counts[col] = counts.get(col, 0) + 1
            renamed.append(col if counts[col] == 1 else f"{col}_{counts[col]}")
        df.columns = renamed
    return df

def chart(df, kind, x, y, title, color=None):
    st.subheader(title)
    if df.empty or x not in df.columns or y not in df.columns:
        st.info("No matching records for the current selection.")
        return
    funcs = {"bar": px.bar, "line": px.line, "pie": px.pie}
    args = {"data_frame": df}
    if kind == "pie":
        args.update(names=x, values=y)
    else:
        args.update(x=x, y=y)
    if color and color in df.columns:
        args["color"] = color
    fig = funcs[kind](**args)
    fig.update_layout(template="plotly_dark", paper_bgcolor="#0a1020", plot_bgcolor="#0a1020", font_color="#dfe9fc", height=390, margin=dict(l=10, r=10, t=25, b=20))
    st.plotly_chart(fig, use_container_width=True)

def download(df, filename):
    if not df.empty:
        st.download_button("↓ Export displayed data", df.to_csv(index=False).encode("utf-8-sig"), file_name=filename + ".csv", mime="text/csv")

opts = fetch("options")
st.sidebar.title("◈ AETHER")
st.sidebar.caption("Healthcare Intelligence Command Center")
page = st.sidebar.radio("Workspace", ["Executive Overview", "Hospital Performance", "Population & Cohorts", "Financial Intelligence", "Data Explorer", "Data Governance"])
st.sidebar.divider()
st.sidebar.subheader("Global encounter filters")
classes = ["All"] + [v for v in (opts.get("classes") or []) if v is not None]
genders = ["All"] + [v for v in (opts.get("genders") or []) if v is not None]
cl = st.sidebar.selectbox("Encounter class", classes)
gender = st.sidebar.selectbox("Gender", genders)
params = {"class": cl, "gender": gender}
dates = opts.get("dates")
if dates and len(dates) == 2 and all(dates):
    try:
        min_d, max_d = (date.fromisoformat(str(value)[:10]) for value in dates)
    except (TypeError, ValueError):
        st.sidebar.warning("Backend returned invalid encounter dates; date filtering disabled.")
    else:
        if min_d <= max_d:
            period = st.sidebar.date_input("Encounter date range", value=(min_d, max_d), min_value=min_d, max_value=max_d)
            if isinstance(period, (tuple, list)) and len(period) == 2:
                params.update(start=period[0].isoformat(), end=period[1].isoformat())
            else:
                st.sidebar.warning("Select both start and end dates.")
                st.stop()
p = tuple(sorted(params.items()))
st.title("AETHER / " + page)
st.caption("Interactive healthcare analytics · Global filters apply to encounter-linked analytics · Descriptive, not clinical decision support")

if page == "Executive Overview":
    data = fetch("overview", p)
    k = data.get("kpis") or {}
    metrics = [("Encounters", "encounters", ""), ("Unique patients", "patients", ""), ("Organizations", "organizations", ""), ("Claims", "claims", "$"), ("Payer coverage", "coverage", "$")]
    for col, (label, key, prefix) in zip(st.columns(5), metrics):
        value = k.get(key) or 0
        col.metric(label, f"{prefix}{value:,.0f}")
    left, right = st.columns([2, 1])
    trend = frame(data.get("trend"))
    with left:
        chart(trend, "line", "month", "encounters", "Encounter volume over time")
    with right:
        chart(frame(data.get("classes")), "pie", "category", "value", "Encounter mix")
    chart(frame(data.get("top_conditions")), "bar", "category", "value", "Frequent recorded conditions among selected patients")
    st.caption("Condition counts include records for selected patients, not necessarily only encounters within the selected dates.")
    download(trend, "encounter_trend")


elif page == "Hospital Performance":
    data = fetch("hospital-performance", p)
    k = data.get("summary") or {}
    note = data.get("availability") or {}
    st.subheader("Hospital operations | Encounter-based indicators")
    st.caption("Figures are calculated from the supplied synthetic healthcare encounters; unavailable operational measures are not estimated.")
    daily = frame(data.get("daily_admissions"))
    los = frame(data.get("length_of_stay"))
    visits = frame(data.get("opd_ipd"))
    orgs = frame(data.get("organizations"))
    total_days = len(daily) if not daily.empty else 0
    avg_daily = (pd.to_numeric(daily["admissions"], errors="coerce").sum() / total_days) if total_days else None
    opd = k.get("opd_visits") or 0
    ipd = k.get("ipd_visits") or 0
    denom = opd + ipd
    opd_ratio = f"{100 * opd / denom:.1f}% / {100 * ipd / denom:.1f}%" if denom else "N/A"
    claim = k.get("total_claim_amount")
    coverage = k.get("payer_coverage_amount")
    cards = [
        ("Daily inpatient starts*", f"{avg_daily:,.1f}" if avg_daily is not None else "N/A", "Mean across days with inpatient starts"),
        ("Average inpatient stay*", f"{k['avg_inpatient_stay_days']:,.2f} days" if k.get("avg_inpatient_stay_days") is not None else "N/A", "Encounter START to STOP"),
        ("Bed occupancy rate", "N/A", "Bed census/capacity unavailable"),
        ("Emergency response time", "N/A", "Response timestamps unavailable"),
        ("OPD / IPD mix*", opd_ratio, "Mapped encounter classes"),
        ("Lab turnaround time", "N/A", "Order/result timestamps unavailable"),
        ("Claim amount*", f"${claim:,.0f}" if claim is not None else "N/A", "Not department revenue"),
        ("Claim approval rate", "N/A", "Approval decisions unavailable"),
    ]
    for start in (0, 4):
        for col, (label, value, help_text) in zip(st.columns(4), cards[start:start + 4]):
            col.metric(label, value, help=help_text)
    st.caption("*Derived proxy or encounter classification; see methodology below. N/A indicates a missing source field, not a zero value.")
    left, right = st.columns(2)
    with left:
        chart(daily, "line", "day", "admissions", "Daily inpatient encounter starts")
    with right:
        chart(los, "line", "month", "days", "Average inpatient encounter duration (days)")
    left, right = st.columns(2)
    with left:
        if not visits.empty and {"month", "visit_type", "visits"}.issubset(visits.columns):
            chart(visits[visits["visit_type"].isin(["OPD", "IPD"])], "bar", "month", "visits", "OPD vs IPD trends", color="visit_type")
        else:
            st.info("No OPD/IPD records for the selected filters.")
    with right:
        chart(orgs, "bar", "organization", "claim_amount", "Claim amounts by organization (not department revenue)")
    st.subheader("Operational KPIs requiring additional data")
    missing = [
        ("Bed occupancy rate", note.get("bed_occupancy", "Unavailable")),
        ("Emergency response time", note.get("emergency_response", "Unavailable")),
        ("Laboratory turnaround time", note.get("lab_turnaround", "Unavailable")),
        ("Revenue by department", "Unavailable: no department attribution; chart above shows claims by organization."),
        ("Insurance claim approval rate", note.get("claim_approval", "Unavailable")),
    ]
    st.dataframe(pd.DataFrame(missing, columns=["Requested KPI", "Dataset limitation"]), use_container_width=True, hide_index=True)
    with st.expander("Methodology and classification rules"):
        for key in ("daily_admissions", "length_of_stay", "opd_ipd", "revenue", "bed_occupancy", "emergency_response", "lab_turnaround", "claim_approval"):
            st.write(f"**{key.replace('_', ' ').title()}:** {note.get(key, 'No metadata available')}")
        st.write("The daily-start average uses days containing at least one inpatient start, not all calendar days in the selected interval.")
    download(daily, "daily_inpatient_encounters")

elif page == "Population & Cohorts":
    data = fetch("cohorts", p)
    left, right = st.columns(2)
    gender_df = frame(data.get("gender"))
    with left:
        chart(gender_df, "bar", "group_name", "patients", "Patients by gender")
    with right:
        chart(frame(data.get("age")), "bar", "group_name", "encounters", "Encounters by age at visit")
    st.subheader("Cohort metrics")
    st.dataframe(gender_df, use_container_width=True)
    download(gender_df, "cohort_metrics")

elif page == "Financial Intelligence":
    data = fetch("finance", p)
    monthly, payers = frame(data.get("monthly")), frame(data.get("payers"))
    if not monthly.empty and {"month", "claims", "coverage"}.issubset(monthly.columns):
        melted = monthly.melt(id_vars="month", value_vars=["claims", "coverage"], var_name="metric", value_name="amount")
        chart(melted, "line", "month", "amount", "Claims and coverage over time", color="metric")
    else:
        st.info("No financial trend data for this selection.")
    chart(payers, "bar", "payer", "claims", "Top payers by claims")
    st.dataframe(payers, use_container_width=True)
    download(payers, "payer_finance")

elif page == "Data Explorer":
    tables = fetch("health").get("tables") or []
    if not tables:
        st.warning("No datasets were loaded by the backend.")
        st.stop()
    table = st.selectbox("Dataset", tables)
    left, right = st.columns(2)
    limit = left.select_slider("Rows per page", options=[25, 50, 100, 250, 500], value=100)
    first = fetch("explore", tuple(sorted({"table": table, "limit": 1, "offset": 0}.items())))
    total = int(first.get("total") or 0)
    max_page = max(1, (total + limit - 1) // limit)
    page_no = right.number_input("Page", min_value=1, max_value=max_page, value=1, step=1, key=f"page_{table}_{limit}")
    data = fetch("explore", tuple(sorted({"table": table, "limit": limit, "offset": (page_no - 1) * limit}.items())))
    columns = data.get("columns") or []
    df = frame(data.get("rows"), columns=columns)
    # Always use actual DataFrame labels, not stale backend metadata.
    columns = list(df.columns)
    st.caption(f"{total:,} source rows · {len(columns)} columns · page {page_no:,} of {max_page:,}")
    search = st.text_input("Search within current page", help="This search applies only to rows retrieved for the current page.")
    if search and not df.empty:
        mask = df.astype(str).apply(lambda series: series.str.contains(search, case=False, regex=False)).any(axis=1)
        df = df.loc[mask]
    visible = st.multiselect("Visible columns", columns, default=columns[:min(12, len(columns))])
    shown = df[visible] if visible else df
    st.dataframe(shown, use_container_width=True, height=520)
    download(shown, "explorer_" + table)
    st.caption("Exports contain only the displayed page and any applied page-level search, not the full source table.")

else:
    data = fetch("quality")
    df = frame(data.get("tables"), columns=["table", "rows", "columns"])
    left, right = st.columns(2)
    left.metric("Available data domains", len(df))
    right.metric("Total source rows", f"{pd.to_numeric(df['rows'], errors='coerce').fillna(0).sum():,.0f}")
    chart(df, "bar", "table", "rows", "Table volumes")
    st.dataframe(df, use_container_width=True)
    st.warning("Row counts and schemas are inventory checks, not evidence of clinical accuracy. Review source validation reports separately.")
    download(df, "data_inventory")

st.sidebar.divider()
st.sidebar.caption("Privacy: use synthetic or de-identified data only. Keep the backend on localhost; this prototype has no authentication.")
