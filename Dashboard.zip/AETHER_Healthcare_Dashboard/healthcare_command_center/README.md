# AETHER — Healthcare Intelligence Command Center

A Flask + DuckDB backend and Streamlit + Plotly frontend built around the supplied multi-table healthcare dataset.

## Start on Windows (PowerShell)

```powershell
cd healthcare_command_center
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python backend.py
```

In a **second terminal**, from the same folder:

```powershell
.venv\Scripts\activate
streamlit run dashboard.py
```

Visit http://localhost:8501. Backend health: http://127.0.0.1:5000/api/health

The included ZIP archive is automatically extracted into `data/` by the backend at first startup. DuckDB reads the CSVs directly and creates analytical views.

## Modules
- Executive Overview: volume, utilization, costs, trends, encounter classes, conditions
- Population & Cohorts: demographics and age at encounter
- Financial Intelligence: claims and payer coverage
- Data Explorer: page through all source tables, search page, select columns, export
- Data Governance: source inventory

## Architecture
`ZIP -> extracted CSVs -> DuckDB SQL views -> Flask JSON REST API -> Streamlit -> Plotly`.

## Limitations / next hardening steps
This is a local analytics prototype, not a certified clinical product. It does **not** offer diagnostic recommendations. Cohort selection uses encounter-linked patients; conditions shown are patient-level records for selected patients, not necessarily conditions recorded during the selected date range. Data Explorer page search applies only to the currently fetched page. No login, role-based permissions, audit trail, API rate limiting, encrypted PHI storage, or production deployment controls are implemented. Never expose identifiable patient data to a public server. The supplied patient data includes potentially identifying columns such as names and SSNs, so the explorer must remain local and should only be used with synthetic or appropriately de-identified data.

For production: add authentication and authorization, server-side patient masking, API access controls, privacy review, row-level security, validation of monetary semantics, materialized aggregation tables, tests, and observability.
